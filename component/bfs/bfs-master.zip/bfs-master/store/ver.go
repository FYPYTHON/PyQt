package main

const (
	Ver     = "0.1"
	GitSHA1 = "42dff06"
)
