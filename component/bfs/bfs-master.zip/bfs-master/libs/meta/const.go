package meta

const (
	MaxBlockOffset = uint32(4294967295)
)
