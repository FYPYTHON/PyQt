#!/bin/bash
#keepalived script for glusterd

master() {
    systemctl status glusterd
    if [ $? -ne 0 ];then
        systemctl start glusterd
    else
        systemctl restart glusterd
    fi
}

backup() {
    systemctl status glusterd
    if [ $? -ne 0 ];then
        systemctl start glusterd
    fi
}

case $1 in
    master)
        master
    ;;
    backup)
        backup
    ;;
    fault)
        backup
    ;;
    stop)
        backup
        systemctl restart keepalived
    ;;
    *)
        echo $"Usage: $0 {master|backup|fault|stop}"
esac
