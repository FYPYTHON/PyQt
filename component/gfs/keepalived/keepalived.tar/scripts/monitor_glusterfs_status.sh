#!/bin/bash
#check glusterfsd and glusterd process

systemctl status glusterd &>/dev/null
if [ $? -eq 0 ];then
    systemctl status glusterfsd &>/dev/null
    if [ $? -eq 0 ];then
        exit 0
    else
        exit 2
    fi
else
    systemctl start glusterd &>/dev/null
    systemctl stop keepalived &>/dev/null && exit 1
fi

